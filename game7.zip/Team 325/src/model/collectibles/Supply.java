package model.collectibles;

public class Supply implements Collectible {
	public Supply() {}

}
