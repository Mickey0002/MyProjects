package model.world;
import java.lang.Math;
public class TrapCell extends Cell {
	private int trapDamage;

	public TrapCell() {
		super();
		int x = (int)(Math.random()* 3)+1;
		this.trapDamage=x*10;
	}

	public int getTrapDamage() {
		return trapDamage;
	}
	

	

	

	}
