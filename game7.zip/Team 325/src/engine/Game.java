package engine;
import model.characters.Explorer;
import model.characters.Fighter;
import model.characters.Hero;
import model.characters.Medic;
import model.characters.Zombie;
import model.world.Cell;

import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;
import java.util.ArrayList;
public class Game {
	public static ArrayList<Hero> availableHeroes;
	public static ArrayList<Hero> heroes;
	public static ArrayList<Zombie> zombies;
	public static Cell [] [] map;
	
	public static void loadHeroes(String filePath) throws IOException {
	BufferedReader vr = new BufferedReader(new FileReader ("C:\\Users\\lenovo\\OneDrive\\Desktop\\Game"));
	String s = " ";
	String [] line;
	availableHeroes = new ArrayList<Hero>();
	
	while((s = vr.readLine()) != null){
		line = s.split(",");
		String name = line[0];
		String Type = line[1];
		int maxHP = Integer.parseInt(line[2]);
		int maxActions = Integer.parseInt(line[3]);
		int attackDMG = Integer.parseInt(line[4]);
		
		if(line[0].equals("FIGH")) {
			Hero Figh = new Fighter(name, maxHP, attackDMG, maxActions);
			availableHeroes.add(Figh);
		}
		
		if(line[0].equals("MED")) {
			Hero Med = new Medic( name,  maxHP,  attackDMG,  maxActions);
			availableHeroes.add(Med);
		}
		if(line[0].equals("EXP")) {	
			Hero Exp = new Explorer( name, maxHP,  attackDMG, maxActions);
			availableHeroes.add(Exp);
		}
	
	}
	}
}
	


	
	
	
	
	
	
	



	
	