public enum ProcessState {
    READY,RUNNING,BLOCKED,FINISHED
}
