package Graphics;

import java.awt.Color;
import java.awt.Font;
import java.util.ArrayList;
import java.util.Timer;
import java.util.TimerTask;

import javax.swing.ImageIcon;
import javax.swing.JFrame;
import javax.swing.JLabel;
import java.awt.event.*;

import model.world.Champion;

public class loading implements KeyListener
{
	private JFrame frame;
	private ArrayList<Champion> c;
	private JLabel b;
	
	public loading(ArrayList<Champion> x)
	{
		c = x;
		frame = new JFrame("Marvel: Ultimate War");
		frame.setSize(700,400);	
		frame.setResizable(false);
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frame.setIconImage(new ImageIcon("Play Menu.jpg").getImage());
		frame.setLocationRelativeTo(null);
		frame.addKeyListener(this);
		
		new playSound("intro.wav");
		b = new JLabel(new ImageIcon("loading.gif"));
		
		frame.add(b);
		frame.pack();
		
		frame.setVisible(true);
		
		Timer timer = new Timer();
		//new playSound("test22.wav");

		TimerTask task = new TimerTask() {
			public void run()
			{
				frame.dispose();
				new nameSelection(c);
			}
		};
		
		timer.schedule(task, 5800);

	}

	@Override
	public void keyTyped(KeyEvent e) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void keyPressed(KeyEvent e) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void keyReleased(KeyEvent e) {
		// TODO Auto-generated method stub
		
	}
	
	
	
	
}
