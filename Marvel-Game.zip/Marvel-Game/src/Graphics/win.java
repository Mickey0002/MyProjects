package Graphics;

import java.awt.Color;
import java.awt.Font;
import java.util.ArrayList;

import javax.swing.ImageIcon;
import javax.swing.JFrame;
import javax.swing.JLabel;

import model.world.Champion;

public class win
{
	private JFrame frame;
	private JLabel play;
	private String w;
	playSound m;
	
	public win(String winner)
	{
		w = winner;
		
		frame = new JFrame("Marvel: Ultimate War");
		frame.setSize(700,400);	
		frame.setResizable(false);
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frame.setIconImage(new ImageIcon("Play Menu.jpg").getImage());
		frame.setLocationRelativeTo(null);
		
		
		
		play = new JLabel(new ImageIcon("win.gif"));
		
		play.setText("WINNER " + w);
		play.setForeground(Color.white);
		play.setHorizontalTextPosition(JLabel.CENTER);
		play.setFont(new Font("",Font.BOLD,60));
	
		frame.add(play);
		frame.setVisible(true);
		frame.pack();
	}
	
	
	
}
