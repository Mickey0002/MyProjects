package Graphics;

import javax.sound.sampled.Clip;
import javax.swing.*;

import javax.swing.event.*;
import model.world.Champion;

import java.awt.*;
import java.awt.event.*;
import java.util.ArrayList;
import java.util.Timer;
import java.util.TimerTask;


import java.io.*;

public class Main implements KeyListener{
	
	private JFrame frame;
	private JLabel p ;
	private JLabel title;
	private JLabel play;
	private ArrayList<Champion> c;
	
	public Main(ArrayList<Champion> f) 
	{
		c =f ;
		frame = new JFrame("Marvel: Ultimate War");
		frame.setSize(700,400);	
		frame.setResizable(false);
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frame.setIconImage(new ImageIcon("Play Menu.jpg").getImage());
		frame.setLocationRelativeTo(null);
		frame.addKeyListener(this);
		
		frame.getContentPane().setBackground(new Color(1,1,1));
		
		play = new JLabel(new ImageIcon("test.gif"));
		
		JLabel enter = new JLabel("PRESS ENTER ");
		enter.setBounds(50,220,300,50);
		enter.setForeground(Color.white);
		enter.setFont(new Font("MV BOLI",Font.BOLD,20));
		play.add(enter);
	
		frame.add(play);
		frame.setVisible(true);
		frame.pack();
		
		
	
	}


	
	

	
	@Override
	public void keyTyped(KeyEvent e) {
	
		
	}


	@Override
	public void keyPressed(KeyEvent e) {
		// TODO Auto-generated method stub
		
		
	}


	@Override
	public void keyReleased(KeyEvent e) {
		// TODO Auto-generated method stub
		if (e.getKeyCode()==KeyEvent.VK_ENTER) {
			frame.dispose();
		//	m.pause();
			new loading(c);
			
		}

	}


	


	
}
