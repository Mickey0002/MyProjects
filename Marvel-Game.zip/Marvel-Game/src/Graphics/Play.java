package Graphics;

import static org.junit.Assert.assertNotNull;



import java.awt.*;


import java.awt.event.*;
import java.util.ArrayList;
import java.util.TimerTask;
import java.util.Timer;
import javax.swing.*;
import javax.swing.event.*;

import engine.Game;
import engine.Player;
import exceptions.AbilityUseException;
import exceptions.ChampionDisarmedException;
import exceptions.InvalidTargetException;
import exceptions.LeaderAbilityAlreadyUsedException;
import exceptions.LeaderNotCurrentException;
import exceptions.NotEnoughResourcesException;
import exceptions.UnallowedMovementException;
import model.abilities.Ability;
import model.abilities.AreaOfEffect;
import model.abilities.CrowdControlAbility;
import model.abilities.DamagingAbility;
import model.abilities.HealingAbility;
import model.effects.Disarm;
import model.effects.Effect;
import model.effects.Stun;
import model.world.AntiHero;
import model.world.Champion;
import model.world.Cover;
import model.world.Damageable;
import model.world.Direction;
import model.world.Hero;

public class Play  implements MouseInputListener {

	
	private String Arena;
	private String firstPlayerName;
	private String secondPlayerName;
	private ArrayList<Champion> firstPlayerTeam;
	private ArrayList<Champion> secondPlayerTeam;
	private Champion firstLeader;
	private Champion secondLeader;
	private Game game;
	//--------------------------------------------------------------------------------------------------------
	private JFrame frame;
	private JLabel backGround = new JLabel(new ImageIcon("play.png"));
	
	private JLabel startMenu;
	private JLabel start;
	
	//------------------------------------------------------------------------------------------------------- board
	private JLabel board1;
	private JLabel[][] cells;
	private JLabel board2;
	private JLabel [][] object;
	private  ArrayList<JProgressBar> covers;
	private ArrayList<Point> p;
	

	//-----------------------------------------------------------------------------------------------------	currentChampion
	
	private JLabel cur;
	private JLabel curActions;
	private JLabel view;
	
	private JLabel attack;
	private JLabel ability1;
	private JLabel ability2;
	private JLabel ability3;
	private JLabel up;
	private JLabel down;
	private JLabel left;
	private JLabel right;
	private JLabel endTurn;
	private JLabel leaderAbility;
	private JLabel punch;
	
	private JProgressBar hp;
	private JProgressBar mana;
	private JTextArea curInfo;
	private int[] manaC = new int[6];
	
	
	//---------------------------------------------------------------------------------------------------------firstPlayer
	private JLabel firstName;
	private JLabel firstAbility;
	private JLabel first;
	private ArrayList<JLabel> team1;
	private ArrayList<JProgressBar> teamHP1;
	private ArrayList<JProgressBar> teamMana1;
	
	
	//-------------------------------------------------------------------------------------------------------- secondPlayer
	private JLabel secondName;
	private JLabel secondAbility;
	private JLabel second;
	private ArrayList<JLabel> team2;
	private ArrayList<JProgressBar> teamHP2;
	private ArrayList<JProgressBar> teamMana2;
	
	//--------------------------------------------------------------------------------------------------------- info
	
	private JLabel info;
	private JTextArea infoText;
	private JLabel turns;
	

	
	//--------------------------------------------------------------------------------------------------------- for the actions
	
	private boolean Attack ;
	private boolean Directional ;
	private boolean Single;
	private JLabel anime;
	private JLabel abilityName;

	//-------------------------------------------------------------------------------------------------------- for updating
	

	
	private Champion f1;
	private Champion f2;
	private Champion f3;
	private Champion s1;
	private Champion s2;
	private Champion s3;
	private Ability a;
	
	private boolean d1;
	private boolean d2;
	private boolean d3;
	private boolean d4;
	private boolean d5;
	private boolean d6;

			
	public Play(String firstPlayerName,String secondPlayerName,ArrayList<Champion> firstPlayerTeam,ArrayList<Champion> secondPlayerTeam,Champion firstLeader,Champion secondLeader)
	{
		this.firstPlayerName = firstPlayerName;
		this.secondPlayerName = secondPlayerName;
		this.firstPlayerTeam = firstPlayerTeam;
		this.secondPlayerTeam = secondPlayerTeam;
		this.firstLeader = firstLeader;
		this.secondLeader = secondLeader;
		
		Player firstPlayer = new Player(this.firstPlayerName);
		firstPlayer.getTeam().addAll(this.firstPlayerTeam);
		firstPlayer.setLeader(this.firstLeader);
		
		Player secondPlayer = new Player(this.secondPlayerName);
		secondPlayer.getTeam().addAll(this.secondPlayerTeam);
		secondPlayer.setLeader(this.secondLeader);
		
		game = new Game(firstPlayer,secondPlayer);
		
	
				
		
		
		//-----------------------------------------------------------------------------------
		
	
		
		frame = new JFrame("Marvel: Ultimate War");
		frame.setSize(1600,1000);	
		frame.setResizable(false);
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frame.setIconImage(new ImageIcon("Play Menu.jpg").getImage());
		frame.setLayout(null);
		frame.setLocationRelativeTo(null);
		
		
		backGround.setOpaque(true);
		backGround.setBounds(0,0,1600,1000);
		backGround.setBackground(Color.black);
		
		startMenu = new JLabel();
	
		abilityName = new JLabel( new ImageIcon("abilityName.png"));
		abilityName.setBounds(440,400,700,150);
		abilityName.setHorizontalTextPosition(JLabel.CENTER);
		abilityName.setForeground(Color.white);
		abilityName.setFont(new Font("",Font.BOLD,60));
		abilityName.setVisible(false);
		
		backGround.add(abilityName);

		
		anime = new JLabel( new ImageIcon(game.getCurrentChampion().getName()+ "a.png"));
		anime.setBounds(440,200,700,550);
		anime.setVisible(false);
		backGround.add(anime);
		
		
		first= new JLabel();
		//first.setBorder(BorderFactory.createLineBorder(Color.white));
		first.setBounds(440,785,700,150);
		first.setIcon(new ImageIcon("team1.png"));
		backGround.add(first);
		
		second = new JLabel();
	//	second.setBorder(BorderFactory.createLineBorder(Color.white));
		second.setBounds(440,10,700,150);
		second.setIcon(new ImageIcon("team2.png"));

		backGround.add(second);
	//	new playSound("testttt.wav");

		

		
		f1= game.getFirstPlayer().getTeam().get(0);
		f2= game.getFirstPlayer().getTeam().get(1);
		f3= game.getFirstPlayer().getTeam().get(2);
		s1 = game.getSecondPlayer().getTeam().get(0);
		s2 = game.getSecondPlayer().getTeam().get(1);
		s3 = game.getSecondPlayer().getTeam().get(2);
		
		manaC[0] =f1.getMana();
		manaC[1] =f2.getMana();
		manaC[2] =f3.getMana();
		manaC[3] =s1.getMana();
		manaC[4] =s2.getMana();
		manaC[5] =s3.getMana();		
		//--------------------------------------------------------------------------------------------------------------------------------------------- Board
		board1 = new JLabel();
		board1.setBounds(440,200,700,550);
		board1.setLayout(new GridLayout(5,5));
		cells = new JLabel[5][5];
			
		for( int i = 0 ; i < 5 ; ++i)
			for( int j = 0 ; j< 5; ++j)
			{
				JLabel tmp = new JLabel();
				tmp.setIcon(new ImageIcon("cell.png"));
				cells[i][j] = tmp;
			}
		
		for( int i = 4 ; i >= 0 ; --i)
		{
			for( int j = 0 ; j< 5 ;++j)
			{
				board1.add(cells[i][j]);
			}
		}
		
		
		board2 = new JLabel();
		board2.setBounds(440,200,700,550);
		board2.setLayout(new GridLayout(5,5));
		object = new JLabel[5][5];
		
		for( int i = 0 ; i < 5 ; ++i)
			for( int j = 0 ; j< 5; ++j)
			{
				JLabel tmp = new JLabel();
				tmp.addMouseListener(this);
				tmp.setIcon(new ImageIcon("cell.png"));
				object[i][j] = tmp;
			}
		
		for( int i = 4 ; i >= 0 ; --i)
		{
			for( int j = 0 ; j< 5 ;++j)
			{
				board2.add(object[i][j]);
			}
		}
		
	
		for( int i= 0 ; i<game.getFirstPlayer().getTeam().size(); ++i)
			
		{
			Champion tmp = game.getFirstPlayer().getTeam().get(i);
			cells[tmp.getLocation().x][tmp.getLocation().y].setIcon(new ImageIcon("cell1.png"));
			object[tmp.getLocation().x][tmp.getLocation().y].setIcon(new ImageIcon(tmp.getName() + "p.png"));
			}
		
		for( int i= 0 ; i<game.getSecondPlayer().getTeam().size(); ++i)
			
			{
			Champion tmp = game.getSecondPlayer().getTeam().get(i);
			cells[tmp.getLocation().x][tmp.getLocation().y].setIcon(new ImageIcon("cell2.png"));
			object[tmp.getLocation().x][tmp.getLocation().y].setIcon(new ImageIcon(tmp.getName() + "p.png"));
			}
	
	
		Object[][] tmpBoard = game.getBoard();
		covers = new ArrayList<JProgressBar>();
		p = new ArrayList<Point>();
		for( int i = 0 ; i< 5 ;++i)
			for( int j = 0 ; j< 5 ; ++j)
			{
				if(tmpBoard[i][j] instanceof Cover)
			{
					object[i][j].setIcon( new ImageIcon("cover.png"));
				
					JProgressBar tmp= new JProgressBar(0,((Cover) tmpBoard[i][j]).getCurrentHP());
					
					tmp.setValue( ((Cover) tmpBoard[i][j]).getCurrentHP());
					tmp.setBackground(Color.white);
					tmp.setForeground(new Color(34,139,34));
					tmp.setOpaque(true);
					tmp.setBorder(BorderFactory.createLineBorder(Color.white));
					tmp.setBounds(10,80,120,20);
					object[i][j].add(tmp);
					p.add(new Point(i,j));
					covers.add(tmp);
				}
			}
		

		
		
		
		
		backGround.add(board1);
		backGround.add(board2);
	
	//--------------------------------------------------------------------------------------------------------------------------------------------Current Champion
		cur = new JLabel(new ImageIcon("current.png"));
		cur.setBounds(10,175,400,600);
		
		view = new JLabel(new ImageIcon(game.getCurrentChampion().getName() + "c.png"));
		view.setBounds(30,30,330,350);
		cur.add(view);
		
		hp = new JProgressBar(0,game.getCurrentChampion().getMaxHP());
		hp.setValue(game.getCurrentChampion().getMaxHP());
		hp.setBounds(30,390,250,25);
		hp.setBackground(Color.white);
		hp.setForeground(new Color(34,139,34));
		hp.setOpaque(true);
		hp.setBorder(BorderFactory.createLineBorder(Color.white));
		cur.add(hp);
		
		mana = new JProgressBar(0,game.getCurrentChampion().getMana());
		mana.setBounds(30,420,200,25);
		mana.setOpaque(true);
		mana.setBackground(Color.white);
		mana.setForeground(new Color(30,144,255));
		mana.setPreferredSize(new Dimension(200,25));
		mana.setBorder(BorderFactory.createLineBorder(Color.white));
		cur.add(mana);
		
		
		curInfo = new JTextArea();
		curInfo.setBounds(30,450,330,120);
		curInfo.setEditable(false);
		curInfo.setFont(new Font("",Font.BOLD,15));
		curInfo.setBackground(Color.black);
		curInfo.setForeground(Color.white);
		
		String s ="";
		String type ="";
		
		if(game.getCurrentChampion() instanceof Hero)
			type = "Hero";
			
		else if(game.getCurrentChampion() instanceof AntiHero)
		
			type = "Anti-Hero";
		else
			type = "Villain";
		
		
		s = "Name : " + game.getCurrentChampion().getName() + "     " + "Type : " + type + "\n" +
			"HP : " + game.getCurrentChampion().getCurrentHP() + "                 " + "Mana : " + game.getCurrentChampion().getMana() + "\n" +
			"Speed : " + game.getCurrentChampion().getSpeed() + "               " + "Action Points : " + game.getCurrentChampion().getCurrentActionPoints() + "\n"	+
			"Attack Range : " + game.getCurrentChampion().getAttackRange() + "      " + "Attack Range : " + game.getCurrentChampion().getAttackDamage() ;
		
	
		curInfo.setText(s);
		cur.add(curInfo);
		
		
		
		
		
		
		curActions = new JLabel(new ImageIcon("curActions.png"));
		curActions.setBounds(1175,175,400,600);
		
		punch = new JLabel("Punch");
		punch.setBounds(75,10,250,75);
		punch.setIcon(new ImageIcon("attack.png"));
		punch.addMouseListener(this);
		punch.setFont(new Font("",Font.BOLD,25));
		punch.setForeground(Color.white);
		punch.setHorizontalTextPosition(JLabel.CENTER);
		punch.setVisible(false);
		curActions.add(punch);

		attack = new JLabel("ATTACK");
		attack.setBounds(75,10,250,75);
		attack.setIcon(new ImageIcon("attack.png"));
		attack.addMouseListener(this);
		attack.setFont(new Font("",Font.BOLD,25));
		attack.setForeground(Color.white);
		attack.setHorizontalTextPosition(JLabel.CENTER);
		curActions.add(attack);
		
	
	
	
		ability1 = new JLabel(game.getCurrentChampion().getAbilities().get(0).getName());
		ability1.setBounds(50,95,300,100);
		ability1.setIcon(new ImageIcon("championA.png"));
		ability1.addMouseListener(this);
		ability1.setFont(new Font("",Font.BOLD,25));
		ability1.setForeground(Color.white);
		ability1.setHorizontalTextPosition(JLabel.CENTER);
		curActions.add(ability1);
		
		
		ability2 = new JLabel(game.getCurrentChampion().getAbilities().get(1).getName()) ;
		ability2.setBounds(50,205,300,100);
		ability2.setIcon(new ImageIcon("championA.png"));
		ability2.addMouseListener(this);
		ability2.setFont(new Font("",Font.BOLD,25));
		ability2.setForeground(Color.white);
		ability2.setHorizontalTextPosition(JLabel.CENTER);
		curActions.add(ability2);

		ability3 =  new JLabel(game.getCurrentChampion().getAbilities().get(2).getName());
		
		ability3.setBounds(50,315,300,100);
		ability3.setIcon(new ImageIcon("championA.png"));
		ability3.addMouseListener(this);
		ability3.setFont(new Font("",Font.BOLD,25));
		ability3.setForeground(Color.white);
		ability3.setHorizontalTextPosition(JLabel.CENTER);
		curActions.add(ability3);
		
	 	leaderAbility = new JLabel("LeaderAbility");
	 	leaderAbility.setBounds(50,425,300,100);
		leaderAbility.setIcon(new ImageIcon("championA.png"));
		leaderAbility.addMouseListener(this);
		leaderAbility.setFont(new Font("",Font.BOLD,25));
		leaderAbility.setForeground(Color.white);
		leaderAbility.setHorizontalTextPosition(JLabel.CENTER);
		curActions.add(leaderAbility);
		
	 	
		endTurn = new JLabel("END TURN");
		endTurn.setBounds(105,535,200,50);
		endTurn.setIcon(new ImageIcon("endTurn.png"));
		endTurn.addMouseListener(this);
		endTurn.setFont(new Font("",Font.BOLD,20));
		endTurn.setForeground(Color.white);
		endTurn.setHorizontalTextPosition(JLabel.CENTER);
		curActions.add(endTurn);
		
		
		
		up = new JLabel("UP");
	 	down = new JLabel("DOWN");
	 	left = new JLabel("LEFT");
	 	right = new JLabel("RIGHT");
	 
	 	up.setIcon(new ImageIcon("button.png"));
	 	up.addMouseListener(this);
	 	up.setBounds(1325,790,100,75);
	 	up.setForeground(Color.white);
	 	up.setFont(new Font("",Font.BOLD,20));
	 	up.setHorizontalTextPosition(JLabel.CENTER);
	 	backGround.add(up);
	 	
	 	down.setBounds(1325,875,100,75);
	 	down.setForeground(Color.white);
	 	down.addMouseListener(this);
	 	down.setIcon(new ImageIcon("button.png"));
	 	down.setFont(new Font("",Font.BOLD,20));
	 	down.setHorizontalTextPosition(JLabel.CENTER);
	 	backGround.add(down);
	 	
	 	left.setBounds(1215,875,100,75);
	 	left.setForeground(Color.white);
	 	left.addMouseListener(this);
	 	left.setIcon(new ImageIcon("button.png"));
	 	left.setFont(new Font("",Font.BOLD,20));
	 	left.setHorizontalTextPosition(JLabel.CENTER);
	 	backGround.add(left);
	 	
	 	right.setBounds(1435,875,100,75);
	 	right.setForeground(Color.white);
	 	right.addMouseListener(this);
	 	right.setIcon(new ImageIcon("button.png"));
	 	right.setFont(new Font("",Font.BOLD,20));
	 	right.setHorizontalTextPosition(JLabel.CENTER);
	 	backGround.add(right);
	 	
	 	backGround.add(cur);
	 	backGround.add(curActions);
	
	//-------------------------------------------------------------------------------------------------------------------------------------------- First Player

	 
	 	firstName = new JLabel(new ImageIcon("firstName.png"));
		firstName.setBounds(10,880,300,75);
		firstName.setHorizontalTextPosition(JLabel.CENTER);
		firstName.setForeground(Color.white);
		firstName.setFont(new Font("",Font.BOLD,25));
		firstName.setText(this.firstPlayerName);
		backGround.add(firstName);
		
		firstAbility = new  JLabel(new ImageIcon("leaderA1.png"));
		firstAbility.setBounds(320,880,100,75);
		firstAbility.setForeground(Color.white);
		firstAbility.setHorizontalTextPosition(JLabel.CENTER);
		firstAbility.setText("LeaderAbility");
		backGround.add(firstAbility);
		
		teamHP1 = new ArrayList<JProgressBar>();
		teamMana1 = new ArrayList<JProgressBar>();
		
		for( int i=0 ; i< 3; ++i)
		{
			JProgressBar tmp= new JProgressBar(0,firstPlayer.getTeam().get(i).getMaxHP());
			
			tmp.setValue(firstPlayer.getTeam().get(i).getMaxHP());
			tmp.setBackground(Color.white);
			tmp.setForeground(new Color(34,139,34));
			tmp.setOpaque(true);
			tmp.setBorder(BorderFactory.createLineBorder(Color.white));
			teamHP1.add(tmp);
		}
		
		for( int i=0 ; i< 3; ++i)
		{
			JProgressBar tmp= new JProgressBar(0,firstPlayer.getTeam().get(i).getMana());
			
			tmp.setValue(firstPlayer.getTeam().get(i).getMana());
			tmp.setBackground(Color.white);
			tmp.setForeground(new Color(30,144,255));
			tmp.setOpaque(true);
			tmp.setBorder(BorderFactory.createLineBorder(Color.white));
			teamMana1.add(tmp);
		}
	
		teamHP1.get(0).setBounds(50,90,160,15); first.add(teamHP1.get(0));
		teamMana1.get(0).setBounds(50,110,160,15); first.add(teamMana1.get(0));
		
		teamHP1.get(1).setBounds(270,90,160,15); first.add(teamHP1.get(1));
		teamMana1.get(1).setBounds(270,110,160,15); first.add(teamMana1.get(1));
		
		teamHP1.get(2).setBounds(485,90,160,15); first.add(teamHP1.get(2));
		teamMana1.get(2).setBounds(485,110,160,15); first.add(teamMana1.get(2));
		team1 = new ArrayList<JLabel>();
		for( int i= 0  ; i< 3; ++i)
		{
			JLabel j = new JLabel();
			j.addMouseListener(this);
			j.setIcon(new ImageIcon(game.getFirstPlayer().getTeam().get(i).getName() + "t.png"));
			j.setForeground(Color.white);
			j.setHorizontalTextPosition(JLabel.CENTER);
			team1.add(j);
		}
		
		if( f1.equals(game.getFirstPlayer().getLeader()))
			team1.get(0).setText("LEADER");
		
		team1.get(0).setBounds(32,15,200,120);  first.add(team1.get(0));
		if( f2.equals(game.getFirstPlayer().getLeader()))
			team1.get(1).setText("LEADER");
		team1.get(1).setBounds(250,15,200,120); first.add(team1.get(1));
		if( f3.equals(game.getFirstPlayer().getLeader()))
			team1.get(2).setText("LEADER");
		team1.get(2).setBounds(465,15,200,120); first.add(team1.get(2));
		
		
	
		
		
	
	//-------------------------------------------------------------------------------------------------------------------------------------------- second Player

	
		secondName = new JLabel(new ImageIcon("secondName.png"));
		secondName.setBounds(10,20,300,75);
		secondName.setHorizontalTextPosition(JLabel.CENTER);
		secondName.setForeground(Color.white);
		secondName.setFont(new Font("",Font.BOLD,25));
		secondName.setText(this.secondPlayerName);
		backGround.add(secondName);
		
		secondAbility = new  JLabel(new ImageIcon("leaderA2.png"));
		secondAbility.setBounds(320,20,100,75);
		secondAbility.setForeground(Color.white);
		secondAbility.setHorizontalTextPosition(JLabel.CENTER);
		secondAbility.setText("LeaderAbility");
		backGround.add(secondAbility);
		
		teamHP2 = new ArrayList<JProgressBar>();
		teamMana2 = new ArrayList<JProgressBar>();
		
		for( int i=0 ; i< 3; ++i)
		{
			JProgressBar tmp= new JProgressBar(0,secondPlayer.getTeam().get(i).getMaxHP());
			
			tmp.setValue(secondPlayer.getTeam().get(i).getMaxHP());
			tmp.setBackground(Color.white);
			tmp.setForeground(new Color(34,139,34));
			tmp.setOpaque(true);
			tmp.setBorder(BorderFactory.createLineBorder(Color.white));
			teamHP2.add(tmp);
		}
		
		for( int i=0 ; i< 3; ++i)
		{
			JProgressBar tmp= new JProgressBar(0,secondPlayer.getTeam().get(i).getMana());
			
			tmp.setValue(secondPlayer.getTeam().get(i).getMana());
			tmp.setBackground(Color.white);
			tmp.setForeground(new Color(30,144,255));
			tmp.setOpaque(true);
			tmp.setBorder(BorderFactory.createLineBorder(Color.white));
			teamMana2.add(tmp);
		}
		
		teamHP2.get(0).setBounds(50,90,160,15); second.add(teamHP2.get(0));
		teamMana2.get(0).setBounds(50,110,160,15); second.add(teamMana2.get(0));
		
		teamHP2.get(1).setBounds(270,90,160,15); second.add(teamHP2.get(1));
		teamMana2.get(1).setBounds(270,110,160,15); second.add(teamMana2.get(1));
		
		teamHP2.get(2).setBounds(485,90,160,15); second.add(teamHP2.get(2));
		teamMana2.get(2).setBounds(485,110,160,15); second.add(teamMana2.get(2));
	

		
		team2 = new ArrayList<JLabel>();
		for( int i= 0  ; i< 3; ++i)
		{
			JLabel j = new JLabel();
			j.addMouseListener(this);
			j.setIcon(new ImageIcon(game.getSecondPlayer().getTeam().get(i).getName() + "t.png"));
			j.setForeground(Color.white);
			j.setHorizontalTextPosition(JLabel.CENTER);
			team2.add(j);
		}
	
		if( s1.equals(game.getSecondPlayer().getLeader()))
			team2.get(0).setText("LEADER");
		if( s2.equals(game.getSecondPlayer().getLeader()))
			team2.get(1).setText("LEADER");
		if( s3.equals(game.getSecondPlayer().getLeader()))
			team2.get(2).setText("LEADER");
		team2.get(0).setBounds(32,15,200,120); second.add(team2.get(0));
		team2.get(1).setBounds(250,15,200,120); second.add(team2.get(1));
		team2.get(2).setBounds(465,15,200,120); second.add(team2.get(2));
		

		
	//--------------------------------------------------------------------------------------------------------------------------------------------- info
	
		
		info = new JLabel(new ImageIcon("info.png"));
		info.setBounds(1175,10,400,150);
		backGround.add(info);
		
		infoText = new JTextArea();
		infoText.setBackground(Color.black);
		infoText.setForeground(Color.white);
		infoText.setEditable(false);
		infoText.setFont(new Font("",Font.BOLD,13));
		infoText.setBounds(25,20,350,120);
		info.add(infoText);
		
		
		ArrayList<Champion> tmp = new ArrayList<Champion>();
		Champion c = (Champion)game.getTurnOrder().remove();
		while(!game.getTurnOrder().isEmpty())
		{
			tmp.add((Champion)game.getTurnOrder().remove());
		}
		
		for(int i =0 ; i< tmp.size(); ++i)
		{
			for(int j = 0 ; j< tmp.get(i).getAppliedEffects().size() ; ++j)
				if(tmp.get(i).getAppliedEffects().get(j) instanceof Stun)
				{
					
					game.getTurnOrder().insert(tmp.remove(i));
					--i;
				}
		}
		
		
		turns = new JLabel(new ImageIcon(tmp.get(0).getName() + "n.png"));
		
		while(!tmp.isEmpty())
			game.getTurnOrder().insert(tmp.remove(tmp.size()-1));
		
		game.getTurnOrder().insert(c);
		//turns.setBorder(BorderFactory.createLineBorder(Color.white));
		turns.setBounds(250,780,150,90);
		backGround.add(turns);
		
		JLabel name = new JLabel("NEXT CHAMPION");
		name.setForeground(Color.white);
		name.setFont(new Font("",Font.BOLD,20));
		name.setBounds(30,780,200,90);
		backGround.add(name);
	//-----------------------------------------------------------------------------------------------------------------------------------------------adding shit
	
		
		frame.add(backGround);
		frame.setVisible(true);
		
	
	
	}

	@Override
	public void mouseClicked(MouseEvent e) {
		

		boolean m1  = false;
		boolean m2  = false;
		boolean m3  = false;
		
		boolean a1 = false;
		boolean a2 = false;
		boolean a3 = false;
		boolean a4 = false;
		boolean a5 = false;
		
		boolean disarm = false;
		
		for(int i = 0 ; i<game.getCurrentChampion().getAppliedEffects().size(); ++i)
			if(game.getCurrentChampion().getAppliedEffects().get(i) instanceof Disarm)
				disarm = true;
			
		if(disarm)
		{
			punch.setVisible(true);
			attack.setVisible(false);
		}
		else
		{
		
			attack.setVisible(true);
		}

		if(e.getSource().equals(attack))
		{
			new playSound("button.wav");
			Attack = true;
			Directional = false;
			Single =false;
		

		}
	
		if( Attack)
		{
			
				if(e.getSource().equals(up)) {
					try {
						game.attack(Direction.UP);
						new playSound("attack.wav");
						Attack =false;
					} catch (NotEnoughResourcesException | ChampionDisarmedException | InvalidTargetException e1) {
						Attack =false;
						JOptionPane.showMessageDialog(null, e1.getMessage());
					}
				}
				else if(e.getSource().equals(down))
				{
					try {
						game.attack(Direction.DOWN);
						new playSound("attack.wav");
						Attack =false;
					} catch (NotEnoughResourcesException | ChampionDisarmedException | InvalidTargetException e1) {
						Attack =false;
						JOptionPane.showMessageDialog(null, e1.getMessage());
					}
				}
				else if(e.getSource().equals(left))
				{
					try {
						game.attack(Direction.LEFT);
						new playSound("attack.wav");
						Attack =false;
					} catch (NotEnoughResourcesException | ChampionDisarmedException | InvalidTargetException e1) {
						Attack =false;
						JOptionPane.showMessageDialog(null, e1.getMessage());
					}
				}
				else if(e.getSource().equals(right))
				{
					try {
						game.attack(Direction.RIGHT);
						new playSound("attack.wav");
						Attack =false;
					} catch (NotEnoughResourcesException | ChampionDisarmedException | InvalidTargetException e1) {
						Attack =false;
						JOptionPane.showMessageDialog(null, e1.getMessage());
					}
				}
			
				m1 = true;
				m2=false;
				m3 =false;
		}
		
		if(e.getSource().equals(ability1))
		{
			new playSound("button.wav");
			if(game.getCurrentChampion().getAbilities().get(0).getCastArea() == AreaOfEffect.DIRECTIONAL ) 
				{Directional = true;
				Attack = false;
				Single = false;
				a= game.getCurrentChampion().getAbilities().get(0);
				}
			else if(game.getCurrentChampion().getAbilities().get(0).getCastArea() == AreaOfEffect.SINGLETARGET )
				{Single = true;
				Directional = false;
				Attack = false;
					a= game.getCurrentChampion().getAbilities().get(0);
					
				}
			else
			{
				try {
					game.castAbility(game.getCurrentChampion().getAbilities().get(0));
					a1 = true;
				} catch (NotEnoughResourcesException e1) {
					JOptionPane.showMessageDialog(null, e1.getMessage());
				} catch (AbilityUseException e1) {
					JOptionPane.showMessageDialog(null, e1.getMessage());
				} catch (CloneNotSupportedException e1) {
					JOptionPane.showMessageDialog(null, e1.getMessage());
				}
			}
		}
		
		if(e.getSource().equals(ability2))
		{new playSound("button.wav");
			if(game.getCurrentChampion().getAbilities().get(1).getCastArea() == AreaOfEffect.DIRECTIONAL)
			{Directional = true;
			Attack = false;
			Single = false;
			a= game.getCurrentChampion().getAbilities().get(1);
			}
			else if(game.getCurrentChampion().getAbilities().get(1).getCastArea() == AreaOfEffect.SINGLETARGET )
			{Single = true;
			Directional = false;
			Attack = false;
				a= game.getCurrentChampion().getAbilities().get(1);
				
			}
			else
			{
				try {
				
					game.castAbility(game.getCurrentChampion().getAbilities().get(1));
					a2= true;
				} catch (NotEnoughResourcesException e1) {
					JOptionPane.showMessageDialog(null, e1.getMessage());
				} catch (AbilityUseException e1) {
					JOptionPane.showMessageDialog(null, e1.getMessage());
				} catch (CloneNotSupportedException e1) {
					JOptionPane.showMessageDialog(null, e1.getMessage());
				}
			}
			
		}
		
		
		if(e.getSource().equals(ability3))
		{
			new playSound("button.wav");
			if(game.getCurrentChampion().getAbilities().get(2).getCastArea() == AreaOfEffect.DIRECTIONAL)
			{Directional = true;
			Attack = false;
			Single = false;
			a= game.getCurrentChampion().getAbilities().get(2);
			}
			else if(game.getCurrentChampion().getAbilities().get(2).getCastArea() == AreaOfEffect.SINGLETARGET )
			{Directional = false;
			Attack = false;
				Single = true;
			a= game.getCurrentChampion().getAbilities().get(2);
			
			}
			else
			{
				try {
					game.castAbility(game.getCurrentChampion().getAbilities().get(2));
					a3=true;
				} catch (NotEnoughResourcesException e1) {
					JOptionPane.showMessageDialog(null, e1.getMessage());
				} catch (AbilityUseException e1) {
					JOptionPane.showMessageDialog(null, e1.getMessage());
				} catch (CloneNotSupportedException e1) {
					JOptionPane.showMessageDialog(null, e1.getMessage());
				}
			}
			
		}
		
		
		if( Directional)
		{
			if(e.getSource().equals(up)) {
			
					try {
						game.castAbility(a,Direction.UP);
						if(a.equals(game.getCurrentChampion().getAbilities().get(0)))
							a1 = true;
						else if(a.equals(game.getCurrentChampion().getAbilities().get(1)))
							a2 = true;
						else 
							a3 =true;
 
						Directional = false;
					} catch (NotEnoughResourcesException | AbilityUseException | CloneNotSupportedException e1) {
						Directional = false;
						JOptionPane.showMessageDialog(null, e1.getMessage());
					}
			
			}
			else if(e.getSource().equals(down))
			{
				try {
					game.castAbility(a,Direction.DOWN);
					Directional = false;
					if(a.equals(game.getCurrentChampion().getAbilities().get(0)))
						a1 = true;
					else if(a.equals(game.getCurrentChampion().getAbilities().get(1)))
						a2 = true;
					else 
						a3 =true;
				} catch (NotEnoughResourcesException | AbilityUseException | CloneNotSupportedException e1) {
					Directional = false;
					JOptionPane.showMessageDialog(null, e1.getMessage());
				}
			}
			else if(e.getSource().equals(left))
			{
				try {
					game.castAbility(a,Direction.LEFT);
					Directional = false;
					if(a.equals(game.getCurrentChampion().getAbilities().get(0)))
						a1 = true;
					else if(a.equals(game.getCurrentChampion().getAbilities().get(1)))
						a2 = true;
					else 
						a3 =true;
				} catch (NotEnoughResourcesException | AbilityUseException | CloneNotSupportedException e1) {
					Directional = false;
					JOptionPane.showMessageDialog(null, e1.getMessage());
				}
			}
			else if(e.getSource().equals(right))
			{
				try {
					game.castAbility(a,Direction.RIGHT);
					Directional = false;
					if(a.equals(game.getCurrentChampion().getAbilities().get(0)))
						a1 = true;
					else if(a.equals(game.getCurrentChampion().getAbilities().get(1)))
						a2 = true;
					else 
						a3 =true;
				} catch (NotEnoughResourcesException | AbilityUseException | CloneNotSupportedException e1) {
					Directional = false;
					JOptionPane.showMessageDialog(null, e1.getMessage());
				}
			}
			
			m1 = false;
			m2=true;
			m3 =false;
		
		
		}
		
		if(e.getSource().equals(punch))
		{
			new playSound("button.wav");
			Directional = false;
			Attack = false;
			Single = true;
			a= game.getCurrentChampion().getAbilities().get(3);
			
		}
		
		if(Single)
		{
			for(int i = 0 ; i< 5; ++i)
				for(int j = 0 ; j < 5 ; ++j)
					if(e.getSource().equals(object[i][j]))
						try {
							game.castAbility(a, i, j);
							Single = false;
							if(disarm == true)
								a5 =true;
							if(a.equals(game.getCurrentChampion().getAbilities().get(0)))
								a1 = true;
							else if(a.equals(game.getCurrentChampion().getAbilities().get(1)))
								a2 = true;
							else 
								a3 =true;
						} catch (NotEnoughResourcesException | AbilityUseException | InvalidTargetException
								| CloneNotSupportedException e1) {
							Single = false;
							JOptionPane.showMessageDialog(null, e1.getMessage());
						}
			m1 = false;
			m2=false;
			m3 =true;
		}
		
		if(e.getSource().equals(endTurn))
		{
			new playSound("button.wav");
			game.endTurn();
			ability1.setText(game.getCurrentChampion().getAbilities().get(0).getName());
			ability2.setText(game.getCurrentChampion().getAbilities().get(1).getName());
			ability3.setText(game.getCurrentChampion().getAbilities().get(2).getName());
			view.setIcon(new ImageIcon(game.getCurrentChampion().getName()+"c.png"));
			String s ="";
			String type ="";
			
			if(game.getCurrentChampion() instanceof Hero)
				type = "Hero";
				
			else if(game.getCurrentChampion() instanceof AntiHero)
			
				type = "Anti-Hero";
			else
				type = "Villain";
			
			
			s = "Name : " + game.getCurrentChampion().getName() + "     " + "Type : " + type + "\n" +
				"HP : " + game.getCurrentChampion().getCurrentHP() + "                 " + "Mana : " + game.getCurrentChampion().getMana() + "\n" +
				"Speed : " + game.getCurrentChampion().getSpeed() + "               " + "Action Points : " + game.getCurrentChampion().getCurrentActionPoints() + "\n"	+
				"Attack Range : " + game.getCurrentChampion().getAttackRange() + "      " + "Attack Range : " + game.getCurrentChampion().getAttackDamage() ;
			
		
			curInfo.setText(s);
			cur.add(curInfo);
			
			for(int i = 0 ; i<game.getCurrentChampion().getAppliedEffects().size(); ++i)
				if(game.getCurrentChampion().getAppliedEffects().get(i) instanceof Disarm)
					disarm = true;
			

			if(disarm)
			{
				punch.setVisible(true);
				attack.setVisible(false);
			}
			else
			{
				punch.setVisible(false);
				attack.setVisible(true);
			}

			
		}
		

		if(disarm)
		{
			punch.setVisible(true);
			attack.setVisible(false);
		}
		else
		{
			
			attack.setVisible(true);
			punch.setVisible(false);
		}

		
		if(e.getSource().equals(leaderAbility))
		{
			new playSound("button.wav");
			if(game.getFirstPlayer().getTeam().contains(game.getCurrentChampion()))
			{
				try {
					game.useLeaderAbility();
					a4=true;
					firstAbility.setVisible(false);
				} catch (LeaderNotCurrentException | LeaderAbilityAlreadyUsedException e1) {
					JOptionPane.showMessageDialog(null, e1.getMessage());
				}
			}
			else
			{
				try {
					game.useLeaderAbility();
					a4=true;
					secondAbility.setVisible(false);
				} catch (LeaderNotCurrentException | LeaderAbilityAlreadyUsedException e1) {
					JOptionPane.showMessageDialog(null, e1.getMessage());
				}
			}
		}
				
		
		
		
		if( game.getTurnOrder().size() > 1) {
		ArrayList<Champion> tmp = new ArrayList<Champion>();
		Champion c= (Champion)game.getTurnOrder().remove();
				
		while(!game.getTurnOrder().isEmpty())
		{
			tmp.add((Champion)game.getTurnOrder().remove());
		}
		
		
		
		turns.setIcon (new ImageIcon(tmp.get(0).getName() + "n.png"));
		
		while(!tmp.isEmpty())
			game.getTurnOrder().insert(tmp.remove(tmp.size()-1));
		
		game.getTurnOrder().insert(c);
		
	
		}
		else
			turns.setIcon(null);

		anime.setIcon( new ImageIcon(game.getCurrentChampion().getName()+ "a.png"));

		Timer timer = new Timer();
		TimerTask task = new TimerTask() {
			public void run()
			{
				anime.setVisible(false);
				abilityName.setVisible(false);
				
			}
		};
				
		if( a1 || a2 || a3 || a4|| a5)
		{
			if(a5)
				abilityName.setText(game.getCurrentChampion().getAbilities().get(3).getName());
		else if(a1)
				abilityName.setText(game.getCurrentChampion().getAbilities().get(0).getName());
		else if(a2)
				abilityName.setText(game.getCurrentChampion().getAbilities().get(1).getName());
		else if(a3)
				abilityName.setText(game.getCurrentChampion().getAbilities().get(2).getName());
		else if(a4)
				abilityName.setText("Leader Ability");
			
			new playSound("ability.wav");
			anime.setVisible(true);
			abilityName.setVisible(true);
			
			
			
			timer.schedule(task, 2000);
			
		}
	
		
		
		if(!m1 && !m2 && !m3) {
		int x = game.getCurrentChampion().getLocation().x;
		int y = game.getCurrentChampion().getLocation().y;
		if(e.getSource() == up)
		{
			try {
				new playSound("button.wav");
				game.move(Direction.UP);
				cells[game.getCurrentChampion().getLocation().x][game.getCurrentChampion().getLocation().y].setIcon(cells[x][y].getIcon());
				object[game.getCurrentChampion().getLocation().x][game.getCurrentChampion().getLocation().y].setIcon(object[x][y].getIcon());
				
				cells[x][y].setIcon(new ImageIcon("cell.png"));
				object[x][y].setIcon(null);
				
			} catch (NotEnoughResourcesException e1) {
				
				JOptionPane.showMessageDialog(null, e1.getMessage());
			} catch (UnallowedMovementException e1) {
				
				JOptionPane.showMessageDialog(null, e1.getMessage());
			}
			
			
		}
		else if(e.getSource() == down)
		{
			try {
				new playSound("button.wav");
				game.move(Direction.DOWN);
				cells[game.getCurrentChampion().getLocation().x][game.getCurrentChampion().getLocation().y].setIcon(cells[x][y].getIcon());
				object[game.getCurrentChampion().getLocation().x][game.getCurrentChampion().getLocation().y].setIcon(object[x][y].getIcon());
				
				cells[x][y].setIcon(new ImageIcon("cell.png"));
				object[x][y].setIcon(null);
			} catch (NotEnoughResourcesException e1) {
				
				JOptionPane.showMessageDialog(null, e1.getMessage());
			} catch (UnallowedMovementException e1) {
			
				JOptionPane.showMessageDialog(null, e1.getMessage());
			}
		}
		else if(e.getSource() == right)
		{
			try {
				new playSound("button.wav");
				game.move(Direction.RIGHT);
				cells[game.getCurrentChampion().getLocation().x][game.getCurrentChampion().getLocation().y].setIcon(cells[x][y].getIcon());
				object[game.getCurrentChampion().getLocation().x][game.getCurrentChampion().getLocation().y].setIcon(object[x][y].getIcon());
				
				cells[x][y].setIcon(new ImageIcon("cell.png"));
				object[x][y].setIcon(null);
			} catch (NotEnoughResourcesException e1) {
				
				JOptionPane.showMessageDialog(null, e1.getMessage());
			} catch (UnallowedMovementException e1) {
			
				JOptionPane.showMessageDialog(null, e1.getMessage());
			}
		}	
		else if(e.getSource() == left)
		{
			try {
				new playSound("button.wav");
				game.move(Direction.LEFT);
				cells[game.getCurrentChampion().getLocation().x][game.getCurrentChampion().getLocation().y].setIcon(cells[x][y].getIcon());
				object[game.getCurrentChampion().getLocation().x][game.getCurrentChampion().getLocation().y].setIcon(object[x][y].getIcon());
				
				cells[x][y].setIcon(new ImageIcon("cell.png"));
				object[x][y].setIcon(null);
			} catch (NotEnoughResourcesException e1) {
				
				JOptionPane.showMessageDialog(null, e1.getMessage());
			} catch (UnallowedMovementException e1) {
				
				JOptionPane.showMessageDialog(null, e1.getMessage());
			}
		}
		
		}
		
		
		
		
		
		String s ="";
		String type ="";
		
		if(game.getCurrentChampion() instanceof Hero)
			type = "Hero";
			
		else if(game.getCurrentChampion() instanceof AntiHero)
		
			type = "Anti-Hero";
		else
			type = "Villain";
		
		
		s = "Name : " + game.getCurrentChampion().getName() + "     " + "Type : " + type + "\n" +
			"HP : " + game.getCurrentChampion().getCurrentHP() + "                 " + "Mana : " + game.getCurrentChampion().getMana() + "\n" +
			"Speed : " + game.getCurrentChampion().getSpeed() + "               " + "Action Points : " + game.getCurrentChampion().getCurrentActionPoints() + "\n"	+
			"Attack Range : " + game.getCurrentChampion().getAttackRange() + "      " + "Attack Range : " + game.getCurrentChampion().getAttackDamage() ;
		
	
	
		curInfo.setText(s);
		cur.add(curInfo);
		
		hp.setMaximum(game.getCurrentChampion().getMaxHP());
		
		if(f1.equals(game.getCurrentChampion()))
			mana.setMaximum(manaC[0]);
		if(f2.equals(game.getCurrentChampion()))
			mana.setMaximum(manaC[1]);
		if(f3.equals(game.getCurrentChampion()))
			mana.setMaximum(manaC[2]);
		if(s1.equals(game.getCurrentChampion()))
			mana.setMaximum(manaC[3]);
		if(s2.equals(game.getCurrentChampion()))
			mana.setMaximum(manaC[4]);
		if(s3.equals(game.getCurrentChampion()))
			mana.setMaximum(manaC[5]);
		
		
		
		hp.setValue(game.getCurrentChampion().getCurrentHP());
		mana.setValue(game.getCurrentChampion().getMana());
	
		teamHP1.get(0).setValue(f1.getCurrentHP());
		teamMana1.get(0).setValue(f1.getMana());
		
		teamHP1.get(1).setValue(f2.getCurrentHP());
		teamMana1.get(1).setValue(f2.getMana());
		
		teamHP1.get(2).setValue(f3.getCurrentHP());
		teamMana1.get(2).setValue(f3.getMana());
		
		teamHP2.get(0).setValue(s1.getCurrentHP());
		teamMana2.get(0).setValue(s1.getMana());
		
		teamHP2.get(1).setValue(s2.getCurrentHP());
		teamMana2.get(1).setValue(s2.getMana());
		
		teamHP2.get(2).setValue(s3.getCurrentHP());
		teamMana2.get(2).setValue(s3.getMana());
		
		for( int i = 0 ; i< 5 ; i++)
			for(int j=0;j<5;++j)
				if(game.getBoard()[i][j] instanceof Cover)
				{
					object[i][j].setText(""  + ((Cover)game.getBoard()[i][j]).getCurrentHP() );
				}
				else if(game.getBoard()[i][j] == null )
				{
					object[i][j].setIcon(null);
					cells[i][j].setIcon(new ImageIcon("cell.png"));
					object[i][j].setText("");
				}
		
		for(int i= 0 ; i< covers.size(); ++i)
		{
			Point l = p.get(i);
			if(game.getBoard()[l.x][l.y] == null )
			{
				new playSound("shield.wav");
				covers.get(i).setVisible(false);
				p.remove(i);
				covers.remove(i);
				--i;
			}
			else
			{
				covers.get(i).setValue(((Cover)game.getBoard()[l.x][l.y]).getCurrentHP());
			}
		}
		
		
		
		if(!game.getFirstPlayer().getTeam().contains(f1))
		{
			teamHP1.get(0).setVisible(false);
			teamMana1.get(0).setVisible(false);
			team1.get(0).setVisible(false);
			if(d1 == false)
			{
			new playSound("dead.wav");
			d1 = true;
					}
		}
			
		if(!game.getFirstPlayer().getTeam().contains(f2))
		{
			teamHP1.get(1).setVisible(false);
			teamMana1.get(1).setVisible(false);
			team1.get(1).setVisible(false);
			if(d2 == false)
			{
			new playSound("dead.wav");
			d2 = true;
					}
		}
	
			
		if(!game.getFirstPlayer().getTeam().contains(f3))
		{
			teamHP1.get(2).setVisible(false);
			teamMana1.get(2).setVisible(false);
			team1.get(2).setVisible(false);
			if(d3 == false)
			{
			new playSound("dead.wav");
			d3 = true;
					}		}
		
		if(!game.getSecondPlayer().getTeam().contains(s1))
		{
			teamHP2.get(0).setVisible(false);
			teamMana2.get(0).setVisible(false);
			team2.get(0).setVisible(false);
			if(d4 == false)
			{
			new playSound("dead.wav");
			d4 = true;
					}
		}
			
		if(!game.getSecondPlayer().getTeam().contains(s2))
		{
			teamHP2.get(1).setVisible(false);
			teamMana2.get(1).setVisible(false);
			team2.get(1).setVisible(false);
			if(d5 == false)
			{
			new playSound("dead.wav");
			d5 = true;
					}
		}
		
			
		if(!game.getSecondPlayer().getTeam().contains(s3))
		{
			teamHP2.get(2).setVisible(false);
			teamMana2.get(2).setVisible(false);
			team2.get(2).setVisible(false);
			if(d6 == false)
			{
			new playSound("dead.wav");
			d6 = true;
					}
		}
			
		
		if(e.getSource().equals(team1.get(0)))
		{
			String r = "";
			for(int i = 0 ; i < f1.getAppliedEffects().size() ; ++i)
			{
				r += f1.getAppliedEffects().get(i).getName() + "(" + f1.getAppliedEffects().get(i).getDuration() + ") ";
			}
			
			JOptionPane.showMessageDialog(null, r);
		}
		
		if(e.getSource().equals(team1.get(1)))
		{
			String r = "";
			for(int i = 0 ; i < f2.getAppliedEffects().size() ; ++i)
			{
				r += f2.getAppliedEffects().get(i).getName() + "(" + f2.getAppliedEffects().get(i).getDuration() + ") ";
			}
			
			JOptionPane.showMessageDialog(null, r);
		}
		
		if(e.getSource().equals(team1.get(2)))
		{
			String r = "";
			for(int i = 0 ; i < f3.getAppliedEffects().size() ; ++i)
			{
				r += f3.getAppliedEffects().get(i).getName() + "(" + f3.getAppliedEffects().get(i).getDuration() + ") ";
			}
			
			JOptionPane.showMessageDialog(null, r);
		}
		
		if(e.getSource().equals(team2.get(0)))
		{
			String r = "";
			for(int i = 0 ; i < s1.getAppliedEffects().size() ; ++i)
			{
				r += s1.getAppliedEffects().get(i).getName() + "(" + s1.getAppliedEffects().get(i).getDuration() + ") ";
			}
			
			JOptionPane.showMessageDialog(null, r);
		}
		
		if(e.getSource().equals(team2.get(1)))
		{
			String r = "";
			for(int i = 0 ; i < s2.getAppliedEffects().size() ; ++i)
			{
				r += s2.getAppliedEffects().get(i).getName() + "(" + s2.getAppliedEffects().get(i).getDuration() + ") ";
			}
			
			JOptionPane.showMessageDialog(null, r);
		}
		
		if(e.getSource().equals(team2.get(2)))
		{
			String r = "";
			for(int i = 0 ; i < s3.getAppliedEffects().size() ; ++i)
			{
				r += s3.getAppliedEffects().get(i).getName() + "(" + s3.getAppliedEffects().get(i).getDuration() + ") ";
			}
			
			JOptionPane.showMessageDialog(null, r);
		}
		
		Player winner = game.checkGameOver();
		
		if(winner != null)
		{
			
		
			new win(winner.getName());
			
			up.removeMouseListener(this);
			down.removeMouseListener(this);
			left.removeMouseListener(this);
			right.removeMouseListener(this);
			attack.removeMouseListener(this);
			ability1.removeMouseListener(this);
			ability2.removeMouseListener(this);
			ability3.removeMouseListener(this);
			endTurn.removeMouseListener(this);
			leaderAbility.removeMouseListener(this);
			
			for( int i = 0 ; i < team1.size() ;++i)
				team1.get(i).removeMouseListener(this);
			
			for( int i = 0 ; i < team2.size() ;++i)
				team2.get(i).removeMouseListener(this);

			
			for( int i = 0 ; i< 5;++i)
				for(int j = 0 ; j< 5 ;++j)
					{
					cells[i][j].removeMouseListener(this);
					cells[i][j].setVisible(false);
					object[i][j].removeMouseListener(this);
					object[i][j].setVisible(false);

					}
		
		}
	}
	

	@Override
	public void mousePressed(MouseEvent e) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void mouseReleased(MouseEvent e) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void mouseEntered(MouseEvent e) 
	{
		String s ="";
		String type ="";
	if(e.getSource() == team1.get(0))
	{
		
		if(f1 instanceof Hero)
			type = "Hero";
			
		else if(f1 instanceof AntiHero)
		
			type = "Anti-Hero";
		else
			type = "Villain";
		
		
		s = "Name : " + f1.getName() + "     " + "Type : " + type + "\n" +
			"HP : " + f1.getCurrentHP() + "                 " + "Mana : " + f1.getMana() + "\n" +
			"Speed : " + f1.getSpeed() + "               " + "Action Points : " + f1.getCurrentActionPoints() + "\n"	+
			"Attack Range : " + f1.getAttackRange() + "      " + "Attack Range : " + f1.getAttackDamage() ;
		
	
		infoText.setText(s);
		info.add(infoText);
		
	}
	else if(e.getSource() == team1.get(1))
	{
		
		if(f1 instanceof Hero)
			type = "Hero";
			
		else if(f1 instanceof AntiHero)
		
			type = "Anti-Hero";
		else
			type = "Villain";
		
		
		s = "Name : " + f2.getName() + "     " + "Type : " + type + "\n" +
			"HP : " + f2.getCurrentHP() + "                 " + "Mana : " + f2.getMana() + "\n" +
			"Speed : " + f2.getSpeed() + "               " + "Action Points : " + f2.getCurrentActionPoints() + "\n"	+
			"Attack Range : " + f2.getAttackRange() + "      " + "Attack Range : " + f2.getAttackDamage() ;
		
	
		infoText.setText(s);
		info.add(infoText);
		
	}
	else if(e.getSource() == team1.get(2))
	{
		
		if(f1 instanceof Hero)
			type = "Hero";
			
		else if(f1 instanceof AntiHero)
		
			type = "Anti-Hero";
		else
			type = "Villain";
		
		
		s = "Name : " + f3.getName() + "     " + "Type : " + type + "\n" +
			"HP : " + f3.getCurrentHP() + "                 " + "Mana : " + f3.getMana() + "\n" +
			"Speed : " + f3.getSpeed() + "               " + "Action Points : " + f3.getCurrentActionPoints() + "\n"	+
			"Attack Range : " + f3.getAttackRange() + "      " + "Attack Range : " + f3.getAttackDamage() ;
		
	
		infoText.setText(s);
		info.add(infoText);
		
	}
	else if(e.getSource() == team2.get(0))
	{
		
		if(f1 instanceof Hero)
			type = "Hero";
			
		else if(f1 instanceof AntiHero)
		
			type = "Anti-Hero";
		else
			type = "Villain";
		
		
		s = "Name : " + s1.getName() + "     " + "Type : " + type + "\n" +
			"HP : " + s1.getCurrentHP() + "                 " + "Mana : " + s1.getMana() + "\n" +
			"Speed : " + s1.getSpeed() + "               " + "Action Points : " + s1.getCurrentActionPoints() + "\n"	+
			"Attack Range : " + s1.getAttackRange() + "      " + "Attack Range : " + s1.getAttackDamage() ;
		
	
		infoText.setText(s);
		info.add(infoText);
		
	}else if(e.getSource() == team2.get(1))
	{
		
		if(f1 instanceof Hero)
			type = "Hero";
			
		else if(f1 instanceof AntiHero)
		
			type = "Anti-Hero";
		else
			type = "Villain";
		
		
		s = "Name : " + s2.getName() + "     " + "Type : " + type + "\n" +
			"HP : " + s2.getCurrentHP() + "                 " + "Mana : " + s2.getMana() + "\n" +
			"Speed : " + s2.getSpeed() + "               " + "Action Points : " + s2.getCurrentActionPoints() + "\n"	+
			"Attack Range : " + s2.getAttackRange() + "      " + "Attack Range : " + s2.getAttackDamage() ;
		
	
		infoText.setText(s);
		info.add(infoText);
		
	}else if(e.getSource() == team2.get(2))
	{
		
		if(f1 instanceof Hero)
			type = "Hero";
			
		else if(f1 instanceof AntiHero)
		
			type = "Anti-Hero";
		else
			type = "Villain";
		
		
		s = "Name : " + s3.getName() + "     " + "Type : " + type + "\n" +
			"HP : " + s3.getCurrentHP() + "                 " + "Mana : " + s3.getMana() + "\n" +
			"Speed : " + s3.getSpeed() + "               " + "Action Points : " + s3.getCurrentActionPoints() + "\n"	+
			"Attack Range : " + s3.getAttackRange() + "      " + "Attack Range : " + s3.getAttackDamage() ;
		
	
		infoText.setText(s);
		info.add(infoText);
		
	}
	else if(e.getSource() == ability1)
	{

		Ability tmp = game.getCurrentChampion().getAbilities().get(0);
		if(tmp instanceof DamagingAbility) 
		{
			type = "DamagingAbility";
		s = "Name : " + tmp.getName() + "     " + "Type : " + type + "\n" +
				"Action Points : " + tmp.getRequiredActionPoints() + "                 " + "ManaCost : " + tmp.getManaCost() + "\n" +
				"CurrentCoolDown : " + tmp.getCurrentCooldown() + "     " + "BaseCoolDown : " + tmp.getBaseCooldown() + "\n"	+
				"CastArea : " + tmp.getCastArea() + "      " + "Cast Range : " + tmp.getCastRange() + "\n"+ "DamageAmount : " + ((DamagingAbility)tmp).getDamageAmount();
		}
			
		else if(tmp instanceof HealingAbility)
		{
		
			type = "HealingAbility";
			s = "Name : " + tmp.getName() + "     " + "Type : " + type + "\n" +
					"Action Points : " + tmp.getRequiredActionPoints() + "                 " + "ManaCost : " + tmp.getManaCost() + "\n" +
					"CurrentCoolDown : " + tmp.getCurrentCooldown() + "     " + "BaseCoolDown : " + tmp.getBaseCooldown() + "\n"	+
					"CastArea : " + tmp.getCastArea() + "      " + "Cast Range : " + tmp.getCastRange() + "\n"+ "HealAmount : " + ((HealingAbility)tmp).getHealAmount();
			}
		else {
			type = "CrowdControlAbility";
			s = "Name : " + tmp.getName() + "     " + "Type : " + type + "\n" +
					"Action Points : " + tmp.getRequiredActionPoints() + "                 " + "ManaCost : " + tmp.getManaCost() + "\n" +
					"CurrentCoolDown : " + tmp.getCurrentCooldown() + "     " + "BaseCoolDown : " + tmp.getBaseCooldown() + "\n"	+
					"CastArea : " + tmp.getCastArea() + "      " + "Cast Range : " + tmp.getCastRange() + "\n"+ "Effect : " + ((CrowdControlAbility)tmp).getEffect().getName() + "(" +((CrowdControlAbility)tmp).getEffect().getDuration()+")" ;
			}
		
		
	
		infoText.setText(s);
		info.add(infoText);
	}
	else if(e.getSource() == ability2)
	{

		Ability tmp = game.getCurrentChampion().getAbilities().get(1);
		if(tmp instanceof DamagingAbility) 
		{
			type = "DamagingAbility";
		s = "Name : " + tmp.getName() + "     " + "Type : " + type + "\n" +
				"Action Points : " + tmp.getRequiredActionPoints() + "                 " + "ManaCost : " + tmp.getManaCost() + "\n" +
				"CurrentCoolDown : " + tmp.getCurrentCooldown() + "     " + "BaseCoolDown : " + tmp.getBaseCooldown() + "\n"	+
				"CastArea : " + tmp.getCastArea() + "      " + "Cast Range : " + tmp.getCastRange() + "\n"+ "DamageAmount : " + ((DamagingAbility)tmp).getDamageAmount();
		}
			
		else if(tmp instanceof HealingAbility)
		{
		
			type = "HealingAbility";
			s = "Name : " + tmp.getName() + "     " + "Type : " + type + "\n" +
					"Action Points : " + tmp.getRequiredActionPoints() + "                 " + "ManaCost : " + tmp.getManaCost() + "\n" +
					"CurrentCoolDown : " + tmp.getCurrentCooldown() + "     " + "BaseCoolDown : " + tmp.getBaseCooldown() + "\n"	+
					"CastArea : " + tmp.getCastArea() + "      " + "Cast Range : " + tmp.getCastRange() + "\n"+ "HealAmount : " + ((HealingAbility)tmp).getHealAmount();
			}
		else {
			type = "CrowdControlAbility";
			s = "Name : " + tmp.getName() + "     " + "Type : " + type + "\n" +
					"Action Points : " + tmp.getRequiredActionPoints() + "                 " + "ManaCost : " + tmp.getManaCost() + "\n" +
					"CurrentCoolDown : " + tmp.getCurrentCooldown() + "     " + "BaseCoolDown : " + tmp.getBaseCooldown() + "\n"	+
					"CastArea : " + tmp.getCastArea() + "      " + "Cast Range : " + tmp.getCastRange() + "\n"+ "Effect : " + ((CrowdControlAbility)tmp).getEffect().getName() + "(" +((CrowdControlAbility)tmp).getEffect().getDuration()+")" ;
			}
		
		
	
		infoText.setText(s);
		info.add(infoText);
	}
	else if(e.getSource() == ability3)
	{
		Ability tmp = game.getCurrentChampion().getAbilities().get(2);
		if(tmp instanceof DamagingAbility) 
		{
			type = "DamagingAbility";
		s = "Name : " + tmp.getName() + "     " + "Type : " + type + "\n" +
				"Action Points : " + tmp.getRequiredActionPoints() + "                 " + "ManaCost : " + tmp.getManaCost() + "\n" +
				"CurrentCoolDown : " + tmp.getCurrentCooldown() + "     " + "BaseCoolDown : " + tmp.getBaseCooldown() + "\n"	+
				"CastArea : " + tmp.getCastArea() + "      " + "Cast Range : " + tmp.getCastRange() + "\n"+ "DamageAmount : " + ((DamagingAbility)tmp).getDamageAmount();
		}
			
		else if(tmp instanceof HealingAbility)
		{
		
			type = "HealingAbility";
			s = "Name : " + tmp.getName() + "     " + "Type : " + type + "\n" +
					"Action Points : " + tmp.getRequiredActionPoints() + "                 " + "ManaCost : " + tmp.getManaCost() + "\n" +
					"CurrentCoolDown : " + tmp.getCurrentCooldown() + "     " + "BaseCoolDown : " + tmp.getBaseCooldown() + "\n"	+
					"CastArea : " + tmp.getCastArea() + "      " + "Cast Range : " + tmp.getCastRange() + "\n"+ "HealAmount : " + ((HealingAbility)tmp).getHealAmount();
			}
		else {
			type = "CrowdControlAbility";
			s = "Name : " + tmp.getName() + "     " + "Type : " + type + "\n" +
					"Action Points : " + tmp.getRequiredActionPoints() + "                 " + "ManaCost : " + tmp.getManaCost() + "\n" +
					"CurrentCoolDown : " + tmp.getCurrentCooldown() + "     " + "BaseCoolDown : " + tmp.getBaseCooldown() + "\n"	+
					"CastArea : " + tmp.getCastArea() + "      " + "Cast Range : " + tmp.getCastRange() + "\n"+ "Effect : " + ((CrowdControlAbility)tmp).getEffect().getName() + "(" +((CrowdControlAbility)tmp).getEffect().getDuration()+")" ;
			}
		
		
		
	
		infoText.setText(s);
		info.add(infoText);
	} 
	if(e.getSource().equals(punch))
	{		
		Ability tmp = game.getCurrentChampion().getAbilities().get(3);
		s = "Name :  Punch              Type : DamagingAbility"   + "\n" +
			"Action Points : 1          ManaCost : 0"  + "\n" +
			"CurrentCoolDown : " + tmp.getCurrentCooldown() + "     " + "BaseCoolDown : 1" +   "\n"	+
			"CastArea : SINGELTARGET    Cast Range : 1" +
			"\n"+ "DamageAmount : 50" ;
		
		infoText.setText(s);
		info.add(infoText);
	}
	
	
	}

	@Override
	public void mouseExited(MouseEvent e) 
	{
		
		infoText.setText("");
	}

	@Override
	public void mouseDragged(MouseEvent e) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void mouseMoved(MouseEvent e) {
		// TODO Auto-generated method stub
		
	}

	
	
	
	
	
	
}
