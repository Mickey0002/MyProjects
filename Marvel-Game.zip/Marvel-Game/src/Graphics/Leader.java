package Graphics;
import java.awt.*;


import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.MouseEvent;
import java.util.ArrayList;

import javax.swing.*;
import javax.swing.border.Border;
import javax.swing.event.*;

import model.world.Champion;

public class Leader implements MouseInputListener{

	
	private JFrame frame;   
	private JLabel backGround;
	
	private JLabel hud1;
	private JLabel hud2;
	private ArrayList<JLabel> team1;
	private ArrayList<JLabel> team2;
	
	private ArrayList<JLabel> choosen1;
	private ArrayList<JLabel>choosen2;
	
	private JLabel firstName;
	private JLabel secondName;
	private JLabel choose;
	private JLabel view;
	
	
	//-------------------------------------------------getting leader
	
	private boolean fDone;
	private boolean sDone;
	private JLabel next;	
	
	//-------------------------------------------------backEnd
	private String firstPlayerName ;
	private String secondPlayerName;
	private ArrayList<Champion> firstTeam;
	private ArrayList<Champion> secondTeam;
	private Champion firstLeader;
	private Champion secondLeader;
	
	
	
	
	
	
	
	public Leader(String firstPlayerName , String secondPlayerName , ArrayList<Champion> firstTeam, ArrayList<Champion> secondTeam)
	{
		this.firstPlayerName = firstPlayerName;
		this.secondPlayerName = secondPlayerName;
		this.firstTeam = firstTeam;
		this.secondTeam = secondTeam;

		firstLeader = null;
		secondLeader = null;
		new playSound("theme.wav");
		//--------------------------------------------------------------------------------------------------
		frame = new JFrame("Marvel: Ultimate War");
		frame.setSize(1405,1000);
		frame.setResizable(false);
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frame.setIconImage(new ImageIcon("Play Menu.jpg").getImage());
		frame.setLayout(null);
		frame.setLocationRelativeTo(null);
		
		
		backGround = new JLabel(new ImageIcon("vs.png"));
		backGround.setBounds(0,0,1405,1000);
		backGround.setOpaque(true);
		backGround.setBackground(Color.black);
		
		
		
		firstName = new JLabel(new ImageIcon("firstName.png"));
		firstName.setBounds(10,30,300,75);
		firstName.setHorizontalTextPosition(JLabel.CENTER);
		firstName.setForeground(Color.white);
		firstName.setFont(new Font("",Font.BOLD,25));
		firstName.setText(this.firstPlayerName);
		backGround.add(firstName);
		
		secondName = new JLabel(new ImageIcon("secondName.png"));
		secondName.setBounds(1080,30,300,75);
		secondName.setHorizontalTextPosition(JLabel.CENTER);
		secondName.setForeground(Color.white);
		secondName.setFont(new Font("",Font.BOLD,25));
		secondName.setText(this.secondPlayerName);
		backGround.add(secondName);
		
		
		
		view = new JLabel();
		view.setBounds(420,250,550,500);
		backGround.add(view);
		
		choose =  new JLabel(new ImageIcon("selectionMenu.png"));
		choose.setBounds(500,-11,400,100);
		choose.setHorizontalTextPosition(JLabel.CENTER);
		choose.setForeground(Color.white);
		choose.setFont(new Font("",Font.BOLD,25));
		choose.setText("SELECT LEADER");
		backGround.add(choose);
		
		hud1 = new JLabel(new ImageIcon("hud.png"));
		hud1.setBounds(10,150,400,700);
	
		backGround.add(hud1);
	
		hud2 = new JLabel(new ImageIcon("hud.png"));
		hud2.setBounds(980,150,400,700);
		backGround.add(hud2);
		
		choosen1 = new ArrayList<JLabel>();
		choosen2 = new ArrayList<JLabel>();
		for( int i =0 ; i< 3 ;++i)
			choosen1.add(new JLabel(new ImageIcon("leader1.png")));
		
		for( int i =0 ; i< 3 ;++i)
			choosen2.add(new JLabel(new ImageIcon("leader2.png")));
		
		choosen1.get(0).setBounds(40,40,300,200); hud1.add(choosen1.get(0));
		choosen1.get(1).setBounds(40,250,300,200); hud1.add(choosen1.get(1));
		choosen1.get(2).setBounds(40,460,300,200);  hud1.add(choosen1.get(2));
		
		choosen2.get(0).setBounds(40,40,300,200); hud2.add(choosen2.get(0));
		choosen2.get(1).setBounds(40,250,300,200);hud2.add(choosen2.get(1));
		choosen2.get(2).setBounds(40,460,300,200);  hud2.add(choosen2.get(2));
		
		team1 = new ArrayList<JLabel>();
		for( int i = 0 ; i< 3 ; ++i)
		{
			JLabel j = new JLabel(new ImageIcon(firstTeam.get(i).getName() + "l.png"));
			j.addMouseListener(this);
			team1.add(j);
		}
		team2 = new ArrayList<JLabel>();
		for( int i = 0 ; i< 3 ; ++i)
		{
			JLabel j = new JLabel(new ImageIcon(secondTeam.get(i).getName() + "l.png"));
			j.addMouseListener(this);
			team2.add(j);
		}
		
		team1.get(0).setBounds(40,40,300,200); hud1.add(team1.get(0));
		team1.get(1).setBounds(40,250,300,200); hud1.add(team1.get(1));
		team1.get(2).setBounds(40,460,300,200);  hud1.add(team1.get(2));
		
		team2.get(0).setBounds(40,40,300,200); hud2.add(team2.get(0));
		team2.get(1).setBounds(40,250,300,200);hud2.add(team2.get(1));
		team2.get(2).setBounds(40,460,300,200);  hud2.add(team2.get(2));
		
		
		
		
		next = new JLabel(new ImageIcon("abilities.png"));
		next.setHorizontalTextPosition(JLabel.CENTER);
		next.setForeground(Color.white);
		next.setFont(new Font("",Font.BOLD,25));
		next.setBounds(600,850,230,100);
		next.addMouseListener(this);
		next.setText("NEXT");
		next.setVisible(false);
		backGround.add(next);
		
		frame.add(backGround);
		frame.setVisible(true);
	}



	
	
	
	
	
	
	
	
	
	@Override
	public void mouseClicked(MouseEvent e) 
	{
		if(!fDone ) 
		{
			for( int i = 0;  i< 3 ; ++i)
			
				if(e.getSource().equals(team1.get(i)))
				{
					firstLeader = this.firstTeam.get(i);
					team1.get(i).setBorder(BorderFactory.createLineBorder( Color.white));
					choosen1.get(i).setIcon(new ImageIcon("leader.png"));
					fDone = true;
					new playSound("button.wav");
				}
		}
				
			
		else if(!sDone)
		{

			for( int i = 0;  i< 3 ; ++i)
				
				if(e.getSource().equals(team2.get(i)))
				{
					secondLeader = this.secondTeam.get(i);
					team2.get(i).setBorder(BorderFactory.createLineBorder( Color.white));
					choosen2.get(i).setIcon(new ImageIcon("leader.png"));
					sDone = true;
					new playSound("button.wav");
				}		
		}
		
		if(fDone && sDone)
			next.setVisible(true);
		
		if (e.getSource().equals(next)) {
			new playSound("button.wav");
			frame.dispose();
			Play p = new Play( this.firstPlayerName, this.secondPlayerName, this.firstTeam,	this.secondTeam, this.firstLeader, this.secondLeader);

		}
		
	}



	@Override
	public void mousePressed(MouseEvent e) {
		// TODO Auto-generated method stub
		
	}



	@Override
	public void mouseReleased(MouseEvent e) {
		// TODO Auto-generated method stub
		
	}



	@Override
	public void mouseEntered(MouseEvent e) 
	{
		
		
			for( int i = 0 ; i< 3 ;++i)
				if(e.getSource().equals(team1.get(i)))
				view.setIcon(new ImageIcon(this.firstTeam.get(i).getName() + ".png" ));
		
		
		
			for( int i = 0 ; i< 3 ;++i)
				if(e.getSource().equals(team2.get(i)))
				view.setIcon(new ImageIcon(this.secondTeam.get(i).getName() + ".png" ));
		
		

			
			
			
	}



	@Override
	public void mouseExited(MouseEvent e) {

		view.setIcon(null);
		
	}



	@Override
	public void mouseDragged(MouseEvent e) {
		// TODO Auto-generated method stub
		
	}



	@Override
	public void mouseMoved(MouseEvent e) {
		// TODO Auto-generated method stub
		
	}
	
	
	
	
	
	
	
	
	
}
