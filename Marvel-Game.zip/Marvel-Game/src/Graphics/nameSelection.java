package Graphics;

import javax.swing.*;

import javax.swing.event.*;

import model.world.Champion;

import java.awt.*;
import java.awt.event.KeyEvent;
import java.awt.event.KeyListener;
import java.awt.event.MouseEvent;
import java.util.ArrayList;

public class nameSelection implements  MouseInputListener
{

	private JFrame frame;
	private JLabel backGround;
	private JLabel first;
	private JLabel second;
	private JTextField firstPlayerName;
	private JTextField secondPlayerName;
	private JLabel next;
	private JLabel choose;
	//--------------------------------------------
	private ArrayList<Champion> c;
	
	
	public nameSelection(ArrayList<Champion> f)
	{
		
		c = f;
	//------------------------------------------
		
		frame = new JFrame("Marvel: Ultimate War");
		frame.setSize(700,400);	
		frame.setResizable(false);
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frame.setIconImage(new ImageIcon("Play Menu.jpg").getImage());
		frame.setLocationRelativeTo(null);
		
		
		backGround = new JLabel(new ImageIcon("nameSelection.png"));
		backGround.setBounds(0,0,700,400);
		
		first = new JLabel(new ImageIcon("f.png"));
		first.setFont( new Font("",Font.BOLD,20));
		first.setBounds(20,100,200,75);
		first.setText("FIRST PLAYER");
		first.setHorizontalTextPosition(JLabel.CENTER);
		first.setForeground(Color.white);
		backGround.add(first);
		
		second = new JLabel(new ImageIcon("s.png"));
		second.setFont( new Font("",Font.BOLD,20));
		second.setBounds(20,200,200,75);
		second.setText("SECOND PLAYER");
		second.setHorizontalTextPosition(JLabel.CENTER);
		second.setForeground(Color.white);
		backGround.add(second);
		
		
		JLabel p1 =  new JLabel(new ImageIcon("firstName.png"));
		p1.setBounds(390,100,300,75);
		
		firstPlayerName = new JTextField("ENTER NAME");
		secondPlayerName = new JTextField("ENTER NAME");
		
		firstPlayerName.setBounds(20,10,240,55);
		firstPlayerName.setCaretColor(Color.white);
		firstPlayerName.setFont( new Font("",Font.BOLD,16));
		firstPlayerName.setForeground(Color.white);
		firstPlayerName.setBackground(Color.black);
		firstPlayerName.setBorder(null);
		p1.add(firstPlayerName);
		backGround.add(p1);
		

		JLabel p2 =  new JLabel(new ImageIcon("secondName1.png"));
		p2.setBounds(390,200,300,75);
		
		secondPlayerName.setBounds(20,10,240,55);
		secondPlayerName.setCaretColor(Color.white);
		secondPlayerName.setFont( new Font("",Font.BOLD,16));
		secondPlayerName.setForeground(Color.white);
		secondPlayerName.setBackground(Color.black);
		secondPlayerName.setBorder(null);
		p2.add(secondPlayerName);
		backGround.add(p2);

		
		next = new JLabel("NEXT");
		next.setIcon(new ImageIcon("b.png"));
		next.setFont(new Font("Comic Sans MS", Font.BOLD,30));
		next.setBounds(245, 280 , 150,50);
		next.setFocusable(false);
		//next.setBorder(BorderFactory.createLineBorder(Color.WHITE,3,true));
		next.setHorizontalTextPosition(JLabel.CENTER);
		next.setBackground( new Color(53,50,204));
		next.setForeground(Color.WHITE);
		next.setVisible(true);
		next.addMouseListener(this);
		backGround.add(next);

		choose =  new JLabel(new ImageIcon("selectionMenu.png"));
		//choose.setBorder(BorderFactory.createLineBorder(Color.white));
		choose.setBounds(150,-11,400,100);
		choose.setHorizontalTextPosition(JLabel.CENTER);
		choose.setForeground(Color.white);
		choose.setFont(new Font("",Font.BOLD,25));
		choose.setText("CHOOSE NAMES");
		backGround.add(choose);
		frame.add(backGround);
	//	 new playSound("testttt.wav");

		frame.setVisible(true);
	}
	
	
	
	
	@Override
	public void mouseClicked(MouseEvent e) {
		
		if(firstPlayerName.getText().length() == 0 || secondPlayerName.getText().length() == 0 )	
		{
			JOptionPane.showMessageDialog(null, "Please Enter A Name");
		}
		else
		{
			new playSound("button.wav");
			frame.dispose();
			
			Selection s = new Selection(firstPlayerName.getText(),secondPlayerName.getText() , c);
			}
	}

	@Override
	public void mousePressed(MouseEvent e) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void mouseReleased(MouseEvent e) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void mouseEntered(MouseEvent e) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void mouseExited(MouseEvent e) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void mouseDragged(MouseEvent e) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void mouseMoved(MouseEvent e) {
		// TODO Auto-generated method stub
		
	}




	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
}
