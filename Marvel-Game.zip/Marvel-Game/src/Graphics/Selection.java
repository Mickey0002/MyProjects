package Graphics;
import java.awt.*;



import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.MouseEvent;
import java.io.File;
import java.util.ArrayList;

import javax.sound.sampled.AudioFormat;
import javax.sound.sampled.AudioInputStream;
import javax.sound.sampled.AudioSystem;
import javax.sound.sampled.Clip;
import javax.sound.sampled.DataLine;
import javax.swing.*;
import javax.swing.border.Border;
import javax.swing.event.*;


import model.world.AntiHero;
import model.world.Champion;
import model.world.Hero;

public class Selection implements  MouseInputListener{

	

	private JFrame frame;   
	private JLabel backGround;
	
	//---------------------------------------------------------------------------------- icons of champions and Player Names
	private ArrayList<JLabel> buttons;
	private ArrayList<JLabel> labels;
	private JLabel firstName;
	private JLabel secondName;
	private JLabel choose;
	
	//----------------------------------------------------------------------------------displaying Champion
	private JLabel img;
	private JLabel info;
	private JLabel ability1;
	private JLabel ability2;
	private JLabel ability3;
	private JTextArea infoText;
	private JLabel championName;
	
	
	//-------------------------------
	private boolean[] disabled; // code of choosing champions
	private int firstSize;
	private int secondSize;
	private JButton doneFirst;
	private boolean doneF;
	private JButton doneSecond;
	private boolean doneS;

	
	//--------------------------------
	private ArrayList<Champion> champions;
	private ArrayList<Champion> firstPlayerTeam;
	private ArrayList<Champion> secondPlayerTeam;
	private String firstPlayerName;
	private String secondPlayerName;
	private playSound sound;
	
	public Selection(String firstPlayerName , String secondPlayerName , ArrayList<Champion> c)
	
	{
		champions = c;
		disabled =  new boolean[15];
		firstSize =0 ;
		secondSize =0 ;
		doneF = false;
		doneS = false;
		firstPlayerTeam = new ArrayList<Champion>();
		secondPlayerTeam = new ArrayList<Champion>();
		this.firstPlayerName =firstPlayerName;
		this.secondPlayerName = secondPlayerName;
		
		
		doneFirst = new JButton("READY");
		doneFirst.setEnabled(false);
		doneFirst.setFocusable(false);
		doneFirst.setBackground( new Color(65,105,225));
		doneFirst.setBorder(BorderFactory.createLineBorder( Color.WHITE, 6, true));
		doneFirst.setFont(new Font("Comic Sans MS", Font.BOLD,30));
		doneFirst.setForeground(Color.WHITE);
		
		doneSecond = new JButton("READY");
		doneSecond.setEnabled(false);
		doneSecond.setFocusable(false);
		doneSecond.setBackground( new Color(178,34,34));
		doneSecond.setBorder(BorderFactory.createLineBorder( Color.WHITE, 6, true));
		doneSecond.setFont(new Font("Comic Sans MS", Font.BOLD,30));
		doneSecond.setForeground(Color.WHITE);
		
		
		frame = new JFrame("Marvel: Ultimate War");
		frame.setSize(1405,1000);
		frame.setResizable(false);
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frame.setIconImage(new ImageIcon("Play Menu.jpg").getImage());
		frame.setLayout(null);
		frame.setLocationRelativeTo(null);
		
	
	
		backGround = new JLabel(new ImageIcon("bacl.jpg"));
		
		backGround.setBounds(0,0,1405,1000);
		
		
		
		firstName = new JLabel(new ImageIcon("firstName.png"));
		firstName.setBounds(10,10,300,75);
		firstName.setHorizontalTextPosition(JLabel.CENTER);
		firstName.setForeground(Color.white);
		firstName.setFont(new Font("",Font.BOLD,25));
		firstName.setText(this.firstPlayerName);
		backGround.add(firstName);
		
		secondName = new JLabel(new ImageIcon("secondName.png"));
		secondName.setBounds(1080,10,300,75);
		secondName.setHorizontalTextPosition(JLabel.CENTER);
		secondName.setForeground(Color.white);
		secondName.setFont(new Font("",Font.BOLD,25));
		secondName.setText(this.secondPlayerName);
		backGround.add(secondName);
		
		choose =  new JLabel(new ImageIcon("selectionMenu.png"));
		//choose.setBorder(BorderFactory.createLineBorder(Color.white));
		choose.setBounds(520,-11,400,100);
		choose.setHorizontalTextPosition(JLabel.CENTER);
		choose.setForeground(Color.white);
		choose.setFont(new Font("",Font.BOLD,25));
		choose.setText("SELECT CHAMPIONS");
		backGround.add(choose);
		
		
		labels = new ArrayList<JLabel>();
		for( int i = 0 ; i< 15 ;++i)
		{
			JLabel j = new JLabel(new ImageIcon("selected.png"));
			labels.add(j);
			
			
			
		}
		
		
		buttons = new ArrayList<JLabel>();
		for( int i = 0 ; i< 15 ;++i)
		{
			JLabel b = new JLabel(""+i);
			b.addMouseListener(this);
		//	b.setBorder(BorderFactory.createLineBorder(Color.white,3,true));
			b.setFocusable(false);
			b.setIcon( new ImageIcon("img"+i+".png"));
			b.setOpaque(true);
			b.setBackground(Color.black);
			buttons.add(b);
			
			
			
		}
	
		
	
		labels.get(0).setBounds(60,600,150,170);
		labels.get(1).setBounds(220,600,150,170);
		labels.get(2).setBounds(380,600,150,170); 
		labels.get(3).setBounds(540,600,150,170);
		labels.get(4).setBounds(700,600,150,170); 
		labels.get(5).setBounds(860,600,150,170);
		labels.get(6).setBounds(1020,600,150,170);
		labels.get(7).setBounds(1180,600,150,170); 
		
		labels.get(8).setBounds(135,780,150,170); 
		labels.get(9).setBounds(295,780,150,170); 
		labels.get(10).setBounds(455,780,150,170); 
		labels.get(11).setBounds(615,780,150,170); 
		labels.get(12).setBounds(775,780,150,170); 
		labels.get(13).setBounds(935,780,150,170); 
		labels.get(14).setBounds(1095,780,150,170); 
		
		backGround.add(labels.get(0));	backGround.add(labels.get(6));	backGround.add(labels.get(12));
		backGround.add(labels.get(1));	backGround.add(labels.get(7));	backGround.add(labels.get(13));
		backGround.add(labels.get(2));	backGround.add(labels.get(8));	backGround.add(labels.get(14));
		backGround.add(labels.get(3));	backGround.add(labels.get(9));
		backGround.add(labels.get(4));	backGround.add(labels.get(10));
		backGround.add(labels.get(5));	backGround.add(labels.get(11));
		
		
		buttons.get(0).setBounds(60,600,150,170); 
		buttons.get(1).setBounds(220,600,150,170);labels.get(1).add(buttons.get(1));
		buttons.get(2).setBounds(380,600,150,170); labels.get(2).add(buttons.get(2));
		buttons.get(3).setBounds(540,600,150,170);labels.get(3).add(buttons.get(3));
		buttons.get(4).setBounds(700,600,150,170); labels.get(4).add(buttons.get(4));
		buttons.get(5).setBounds(860,600,150,170); labels.get(5).add(buttons.get(5));
		buttons.get(6).setBounds(1020,600,150,170);labels.get(6).add(buttons.get(6));
		buttons.get(7).setBounds(1180,600,150,170); labels.get(7).add(buttons.get(7));
		
		buttons.get(8).setBounds(135,780,150,170); labels.get(8).add(buttons.get(8));
		buttons.get(9).setBounds(295,780,150,170); labels.get(9).add(buttons.get(9));
		buttons.get(10).setBounds(455,780,150,170); labels.get(10).add(buttons.get(10));
	 	buttons.get(11).setBounds(615,780,150,170); labels.get(11).add(buttons.get(11));
		buttons.get(12).setBounds(775,780,150,170); labels.get(12).add(buttons.get(12));
		buttons.get(13).setBounds(935,780,150,170); labels.get(13).add(buttons.get(13));
		buttons.get(14).setBounds(1095,780,150,170); labels.get(14).add(buttons.get(14));
		
		
		
		backGround.add(buttons.get(0)); backGround.add(buttons.get(5)); backGround.add(buttons.get(10));
		backGround.add(buttons.get(1));	backGround.add(buttons.get(6));	backGround.add(buttons.get(11));
		backGround.add(buttons.get(2));	backGround.add(buttons.get(7));	backGround.add(buttons.get(12));
		backGround.add(buttons.get(3));	backGround.add(buttons.get(8));	backGround.add(buttons.get(13));
		backGround.add(buttons.get(4));	backGround.add(buttons.get(9));	backGround.add(buttons.get(14));
		
	
		

		
		img = new JLabel();
		
		img.setBounds(20,90,600,500);
		img.setIcon(new ImageIcon("empty.png"));
		
		
		info = new JLabel(new ImageIcon("info2.png"));
		
		info.setBounds(640,250,500,300);
		
		championName = new JLabel(new ImageIcon("champions.png"));
		championName.setBounds(640,140,250,100);
		championName.setHorizontalTextPosition(JLabel.CENTER);
		championName.setForeground(Color.white);
		championName.setFont(new Font("",Font.BOLD,24));
		
		
		
		ability1 = new JLabel(new ImageIcon("abilities.png"));
		ability1.setHorizontalTextPosition(JLabel.CENTER);
		ability1.setForeground(Color.white);
		ability1.setFont(new Font("",Font.BOLD,16));
		ability1.setBounds(1150,250,230,100);
		
		ability2 = new JLabel(new ImageIcon("abilities.png"));
		ability2.setHorizontalTextPosition(JLabel.CENTER);
		ability2.setForeground(Color.white);
		ability2.setFont(new Font("",Font.BOLD,16));
		ability2.setBounds(1150,360,230,100);
		
		ability3 = new JLabel(new ImageIcon("abilities.png"));
		ability3.setHorizontalTextPosition(JLabel.CENTER);
		ability3.setForeground(Color.white);
		ability3.setFont(new Font("",Font.BOLD,16));
		ability3.setBounds(1150,470,230,100);
		
		infoText = new JTextArea();
		infoText.setBackground(Color.black);
		infoText.setBounds(30,42,435 ,230);
		infoText.setForeground(Color.white);
		infoText.setFont( new Font("" , Font.BOLD, 20));
		infoText.setEditable(false);
		info.add(infoText);
	
	
	
		backGround.add(img);
		backGround.add(info);
		backGround.add(championName);
		backGround.add(ability1);
		backGround.add(ability2);
		backGround.add(ability3);
	
		
		
		frame.add(backGround);
		frame.setVisible(true);
	}


	@Override
	public void mouseClicked(MouseEvent e) {
		
		
		
		if( !doneF) {
		
				for( int i = 0 ; i < buttons.size() ; ++i) //adding in firstPlayer
				{
		
					
					if(e.getSource().equals(buttons.get(i)) &&  disabled[i] == false && firstSize < 3)
					{
					
					
						firstPlayerTeam.add(champions.get(i));
						firstSize += 1;
						disabled[i] = true;
						labels.get(i).setIcon(new ImageIcon("firstPlayer.png"));
						new playSound("button.wav");
						
					}
					else if(e.getSource().equals(buttons.get(i)) && firstSize > 0 && firstPlayerTeam.contains(champions.get(i)))
					{
						
						firstPlayerTeam.remove(champions.get(i));
						firstSize -= 1;
						disabled[i] = false;
						labels.get(i).setIcon(new ImageIcon("selected.png"));
						new playSound("shield.wav");
					}
				
			
				}
				
				if(firstSize == 3)
					doneF = true;
		
		}
		
		
		
		
		
		if(doneF && !doneS)
		{	
			
	 
		
	 		for( int i = 0 ; i < buttons.size() ; ++i)
	 			{
		
	 			if(e.getSource().equals(buttons.get(i)) &&  disabled[i] == false && secondSize < 3)
					{
					
	 				
	 					secondPlayerTeam.add(champions.get(i));
						secondSize += 1;
						disabled[i] = true;
						labels.get(i).setIcon(new ImageIcon("seconPlayer.png"));
						new playSound("button.wav");
						
					}
	 			else if(e.getSource().equals(buttons.get(i)) && secondSize > 0 && secondPlayerTeam.contains(champions.get(i)))
				{
					
					secondPlayerTeam.remove(champions.get(i));
					secondSize -= 1;
					disabled[i] = false;
					labels.get(i).setIcon(new ImageIcon("selected.png"));
					new playSound("button.wav");
				}
			
	 		}
	 	

			if(secondSize == 3)
				doneS =true;
					
				
			}
		
		
			if( doneS)
			{
				sound.pause();
				frame.dispose();
				new Leader( firstPlayerName , secondPlayerName ,  firstPlayerTeam, secondPlayerTeam);
			}
		
	
				
	 }
		
		
	


	@Override
	public void mousePressed(MouseEvent e) {
		
		
	}


	@Override
	public void mouseReleased(MouseEvent e) 
	{
	
		
	}


	@Override
	public void mouseEntered(MouseEvent e) {
	
	String s = "";	
	String t ="";
	for( int i = 0 ; i < 15 ; ++i)
		if(e.getSource().equals(buttons.get(i)))
		{
			switch(i)
			{
			case 0: sound =new playSound("captain america.wav");break;
			case 1: sound =new playSound("deadpool.wav");break;
			case 2: sound = new playSound("dr strange.wav");break;
			case 3: sound =new playSound("electo.wav");break;
			case 4: sound = new playSound("ghost rider.wav");break;
			case 5: sound =new playSound("hela.wav");break;
			case 6: sound =new playSound("hulk.wav");break;
			case 7: sound =new playSound("iceman.wav");break;
			case 8: sound =new playSound("ironman.wav");break;
			case 9: sound =new playSound("loki.wav");break;
			case 10: sound =new playSound("quicksilver.wav");break;
			case 11: sound = new playSound("spiderman.wav");break;
			case 12: sound =new playSound("thor.wav");break;
			case 13 : sound =new playSound("venom.wav");break;
			default: sound = new playSound("yellow jacket.wav");break;
			}
			
			
			img.setIcon(new ImageIcon(champions.get(i).getName() + ".png"));
			Champion tmp = champions.get(i);
			if( tmp instanceof Hero)
				t = "Hero";
			else if( tmp instanceof AntiHero)
				t ="AntiHero";
			else
				t = "Villain";
			
			s +=  "Type : "+ t +"\n" + "MaxHp : " + tmp.getMaxHP() + "\n" + "Mana : " + tmp.getMana() + "\n" + "Action Points : " + tmp.getMaxActionPointsPerTurn() + "\n"
					+ "Speed : " + tmp.getSpeed() + "\n" + "Attack Damage : " + tmp.getAttackDamage() + "\n" + "Attack Range : " + tmp.getAttackRange();
			championName.setText(tmp.getName());
			ability1.setText(tmp.getAbilities().get(0).getName());
			ability2.setText(tmp.getAbilities().get(1).getName());
			ability3.setText(tmp.getAbilities().get(1).getName());
		}
	infoText.setText(s);
	infoText.setEditable(false);
	
	}


	@Override
	public void mouseExited(MouseEvent e) {
		img.setIcon(new ImageIcon("empty.png"));
		infoText.setText("");
		infoText.setEditable(false);
		championName.setText("");
		ability1.setText("");
		ability2.setText("");
		ability3.setText("");
		sound.pause();
	
	}


	@Override
	public void mouseDragged(MouseEvent e) {
		
		
	}


	@Override
	public void mouseMoved(MouseEvent e) {
	
		
	}


	
	
	
	
}
